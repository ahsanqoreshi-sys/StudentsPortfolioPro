rootProject.name = "StudentsPortfolioPro"
include(":app")
