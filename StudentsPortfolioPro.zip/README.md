# StudentsPortfolioPro
This is a simple Android Studio project (Kotlin + Jetpack Compose + Room) for a Student Portfolio app (Modern Cards Style).

Features:
- Add / Edit / Delete students
- Store students locally using Room (SQLite)
- Simple card-style UI (Jetpack Compose)
- Photo URI field (users can paste a content:// or file:// URI)

How to use:
1. Download and unzip the project.
2. Open in Android Studio (Arctic Fox or later). If using a different Kotlin/Gradle plugin, update versions in build files.
3. Build and run on an Android device or emulator.

Notes:
- I provided a ready-to-import project; I could build an APK for you if you want but I cannot compile it within this chat environment. You can compile it locally in Android Studio (File -> Open -> select project).
- If you want, I can instead produce a minimal APK by preparing a GitHub Actions workflow or guiding you step-by-step to build the APK on your machine.
